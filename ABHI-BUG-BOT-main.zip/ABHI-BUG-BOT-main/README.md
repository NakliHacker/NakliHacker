   # ABHI-BUG-BOT
<div align="center">
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Ribeye&size=50&pause=1000&color=F710B1&center=true&width=910&height=100&lines=I'M+ABHI--BUG-BOT;Multi+Divice+Whatsapp+Bug+Bot;Coded+By+ABHISHEK SURESH" alt="Typing SVG" /></a>
  
<p align="center">  
  <a href="https://youtube.com/@comedymelodych8468">
    <img alt=ABHISHEK-SER height="300" src="https://i.ibb.co/7bPPRQ0/4bf4b7e0b042.jpg">
   
</a> 
    
</p>
<p align="center">
<a 

####  
ABHI-BUG-BOT Multi Device WhatsApp Bug Bot.

***

#### SETUP

 Fork The Repo
    <br>
<a href="https://github.com/AbhishekSuresh2/ABHI-BUG-BOT/fork"><img title="ABHISHEK-SER" src="https://img.shields.io/badge/FORK Bot-BOT?color=black&style=for-the-badge&logo=stackshare"></a>

## `NO NEED TO SCAN QR CODE PAIRING CODE ADDED`

## `For Termux/Ssh/Ubuntu`
```
apt update
apt upgrade
pkg install git -y
pkg install nodejs -y
git clone USE YOUR FORK LINK
cd ABHI-BUG-BOT
npm install
npm start

```
## `For Codespace`
```
npm install
npm start

```

